VERSION OF ANDROID STUDIO: 1.3.2
JRE: 1.8.0_45-b14 amd64

PROJECT TITLE: Lifehack
PURPOSE OF PROJECT: Lifehack 5 ways to cool your drink
VERSION or DATE: 04.09.2015
AUTHOR: Eugene Guzik

USER INSTRUCTIONS:
After the game starts first you see a splash screen, that changes to a next page in 2 seconds, where you should enter your name.
Then click "Continue" button. After this you will see a page with information to read.
Then click "Continue to Quiz" button. After this you will see a page with quiz questions, you should enter your answers for these questions.
Then click "Continue" button. After this you will see a page with summary for your quiz.

Thank you for using the app!